

require.config({
    urlArgs: '_t=' + (+new Date()),
    paths: {}
});

require([
    './app'

],function(){
    document.addEventListener("deviceready", onDeviceReady, false);

    function onDeviceReady(){
        
        angular.element(document).ready(function(){
        // bootstrapping angular module
            angular.bootstrap(document, ['ESales']);
        });
    }
    /*angular.element(document).ready(function(){
        // bootstrapping angular module
        angular.bootstrap(document, ['Chatslokomedia']);

    }); */
});