      var app = angular.module('ESales', [
      "ngRoute",
      "ngTouch",
      "mobile-angular-ui",
      "LocalStorageModule",
      "ngMap","ngSignaturePad"
    ]);

    app.config(function($routeProvider, $locationProvider) {
      $routeProvider.when('/',          {templateUrl: "login.html"});
      $routeProvider.when('/beranda',          {templateUrl: "beranda.html"});
	   
    });
    
  

    app.controller('MainController', function($rootScope,$scope,$http,localStorageService,$location,$interval){
    var urlServer='http://hanedastore.co.id/adminbep/server.php';
	  var urlServerPesan='http://hanedastore.co.id/adminbep/serverpesan.php';
      //inisialisasi scope
    $scope.islogin = false;
    $scope.login={};
	  $scope.currentlokasi={};
    $scope.coordinat={};
	  $scope.pengguna={};
	  $scope.login.aksesuser='Sales';
	 
      $scope.loginFn = function(){
           var username = document.getElementById('username').value;
           var password = document.getElementById('password').value;
           if(username !== '' && password !== ''){
              $http.post(urlServer +'?action=login',$scope.login) 
             .success(function(response,status){
             
              if(response !=='null'){        
              $scope.islogin=true;
              localStorageService.add('user',response['nama_user']);
              localStorageService.add('username',response['username']);
              localStorageService.add('id_user',response['id_user']);
              localStorageService.add('id_pegawai',response['id_pegawai']);
			        localStorageService.add('id_datagroup',response['id_datagroup']);
			        localStorageService.add('level',response['level']);
              $scope.namauser=localStorageService.get('user');
              $scope.username=localStorageService.get('username');
               $scope.pengguna.id_user=localStorageService.get('id_user');
			  $scope.pengguna.id_pegawai=localStorageService.get('id_pegawai');
			  $scope.pengguna.id_datagroup=localStorageService.get('id_datagroup');
			  
              $location.path('/beranda');  
              var options = {  
                  enableHighAccuracy: true,
                  timeout: 8000,
                  maximumAge: 10000
              };
              watchID=navigator.geolocation.watchPosition(onBerhasil, onGagal, options);
              }
              else{
              alert('Gagal login.Periksa Username/Password/Akses User(Sales,Kolektor atau Admin) anda');
              $location.path('/');
              }
             
             });
             
           }
           else
           {
              alert('Username/Password Anda Tidak Boleh Kosong');
              $location.path('/');
           }     
          
           function onBerhasil(position){
           $scope.coordinat=position.coords.latitude+','+position.coords.longitude;
           geocoder = new google.maps.Geocoder();
		       var latlng = new google.maps.LatLng(position.coords.latitude,position.coords.longitude);
           geocoder.geocode({'latLng': latlng}, function(results, status) {
	         if (status == google.maps.GeocoderStatus.OK) {
        	 
	         localStorageService.add('lokasisaatini',results[0].formatted_address);
           $scope.currentlokasi=localStorageService.get('lokasisaatini'); 
		   $scope.lokasianda=localStorageService.get('lokasisaatini');
           localStorageService.add('poslat',position.coords.latitude);
           $scope.poslat=localStorageService.get('poslat');
           localStorageService.add('poslon',position.coords.longitude);
           $scope.poslon=localStorageService.get('poslon');
           } 
            });
           
           
           }
           //akhir berhasil
           function onGagal(error) {
           alert('Sedang mencari lokasi terkini...');
		       $scope.lokasianda="Sedang mencari lokasi...";
           }
            $scope.apply();
        };
        // Set the default value of inputType
        $scope.inputType = 'password';
        // Hide & show password function
        $scope.hideShowPassword = function(){
        if ($scope.inputType == 'password')
           $scope.inputType = 'text';
        else
           $scope.inputType = 'password';
        };
	    // refresh page
      $scope.refresh=function(){
		 
      navigator.geolocation.watchPosition(onPosisi, onPosisihilang, options);
      function onPosisi(position){
           $scope.coordinat=position.coords.latitude+','+position.coords.longitude;
           geocoder = new google.maps.Geocoder();
		       var latlng = new google.maps.LatLng(position.coords.latitude,position.coords.longitude);
           geocoder.geocode({'latLng': latlng}, function(results, status) {
	         if (status == google.maps.GeocoderStatus.OK) { 
	         localStorageService.add('lokasisaatini',results[0].formatted_address);
           $scope.currentlokasi=localStorageService.get('lokasisaatini');
           $scope.lokasianda=localStorageService.get('lokasisaatini');		   
           localStorageService.add('poslat',position.coords.latitude);
           $scope.poslat=localStorageService.get('poslat');
           localStorageService.add('poslon',position.coords.longitude);
           $scope.poslon=localStorageService.get('poslon');
           } 
            });
            
      };
		  
           //akhir berhasil
           function onPosisihilang(error) {
           alert('Sedang mencari lokasi terkini...');
           }
           
      }
	 
  
      
      
      //Keluar dari sistem
      $scope.logout = function(){
          localStorageService.remove('user');
		      localStorageService.remove('username'); 
          localStorageService.remove('id_pegawai');
		      localStorageService.remove('id_user');
          localStorageService.remove('id_datagroup');        
          localStorageService.remove('lokasisaatini');
		      navigator.geolocation.clearWatch(watchID);   
          $scope.islogin=false;  
          $scope.keluar();
          $scope.apply();
      };
       $scope.keluar=function(){
                if (navigator.app) {
                   navigator.app.exitApp();
                }
                else if (navigator.device) {
                    navigator.device.exitApp();
                }
      };
      
    
      //cek localstorage
      $scope.cekLocalStorage = function(){
          if(localStorageService.get('user')){
              $location.path('/beranda');
              $scope.islogin = true;
          }else{
              $location.path('/');
              $scope.islogin = false;
          }
      };
      $scope.cekLocalStorage();
      
      //set tanggal indonesia
      moment.lang('id');
      $scope.hariini=moment().format('DD MMMM YYYY'); 
	    $scope.bulanini=moment().format('MMMM YYYY'); 
      var tick = function() {
       $scope.clock = Date.now();
      }
      tick();
      $interval(tick, 1000);
	 
     
      //animasi loading ketika pindah halaman
      $rootScope.$on("$routeChangeStart", function(){
        $rootScope.loading = true;
      });
      $rootScope.$on("$routeChangeSuccess", function(){
        $rootScope.loading = false;
      });
      // mengetahui user agent
      $scope.userAgent =  navigator.userAgent;
	  

});
